-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2023 at 09:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `byte_basket`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `description`, `status`, `date_created`) VALUES
(1, 'Asus', 'AZUS Brand', 1, '2023-04-03 09:25:50'),
(2, 'Acer', 'Acer Brand', 1, '2023-04-03 09:26:04'),
(3, 'Alienware', 'Alienware Brand', 1, '2023-04-03 09:26:32'),
(4, 'Dell', 'Dell Brand', 1, '2023-04-03 09:28:59'),
(5, 'HP', 'HP Brand', 1, '2023-04-03 09:29:24'),
(6, 'Lenovo', 'Lenovo Brand', 1, '2023-04-03 09:29:53'),
(8, 'InPlay', 'InPlay Brand', 1, '2023-12-22 16:30:33'),
(9, 'ESET', 'ESET Brand', 1, '2023-12-22 16:31:44'),
(10, 'Microsoft', 'Microsoft Brand', 1, '2023-12-22 16:32:18'),
(11, 'N-VISION', 'N-Vision Brand', 1, '2023-12-22 16:33:00'),
(12, 'Intel', 'A powerful CPU', 1, '2023-12-22 17:36:52'),
(14, 'SteelSeries', '', 1, '2023-12-22 18:06:25'),
(15, 'Ramsta', 'OP RAM', 1, '2023-12-22 18:45:20');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(30) NOT NULL,
  `client_id` int(30) NOT NULL,
  `inventory_id` int(30) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(30) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `client_id`, `inventory_id`, `price`, `quantity`, `date_created`) VALUES
(4, 3, 11, 58999, 1, '2023-12-22 20:04:18');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `category` varchar(250) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `description`, `status`, `date_created`) VALUES
(5, 'PC parts/components', 'At a high level, all computers are made up of a processor (CPU), memory, and input/output devices. Each computer receives input from a variety of devices, processes that data with the CPU and memory, and sends results to some form of output.', 1, '2023-12-21 19:37:38'),
(6, 'Laptops', 'A laptop, sometimes called a notebook computer by manufacturers, is a battery- or AC-powered personal computer (PC) smaller than a briefcase. A laptop can be easily transported and used in temporary spaces such as on airplanes, in libraries, temporary offices and at meetings.', 1, '2023-12-21 19:37:53'),
(7, 'Softwares', 'Software is a set of instructions, data or programs used to operate computers and execute specific tasks. It is the opposite of hardware, which describes the physical aspects of a computer. Software is a generic term used to refer to applications, scripts and programs that run on a device.', 1, '2023-12-21 19:39:57');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(30) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` text NOT NULL,
  `default_delivery_address` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `firstname`, `lastname`, `gender`, `contact`, `email`, `password`, `default_delivery_address`, `date_created`) VALUES
(1, 'Mark', 'Cooper', 'Male', '09123654789', 'mcooper@mail.com', '$2y$10$GfYNgIJ8E86XdO6ZA5qwW.55KzSqyl9FDOpVCEZVYmaqwKjCCezKa', 'Sample Address Only', '2023-04-03 13:05:15'),
(2, 'kyle', 'james', 'Male', '09091230292', 'kyle123@gmail.com', '$2y$10$L.12yaeY0FE9QndZwMqEve1b1X4Xj4gb9GcGtj4Vj4vLGs9eva87i', 'Bunawan', '2023-12-22 16:59:41'),
(4, 'Shirley Ann', 'Al-os', 'Female', '09635677123', 'shirley123@yahoo.com', '$2y$10$9DJQDQ.KyyY2oOApdSS1geuXUbR1DHNNqfx7cYUZjfssAOkWhUmR6', 'New Visayas Panabo City', '2023-12-22 20:20:03'),
(5, 'keith', 'anasco', 'Male', '09123127', 'keith@gmail.com', '$2y$10$MZWwDD3glLlNz.UgYMZcPeinTvkJkSuR5kJwJRImprs33woouzGpy', 'panabo', '2023-12-22 23:15:39');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` double NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `product_id`, `quantity`, `date_created`, `date_updated`) VALUES
(1, 1, 10, '2023-04-03 11:30:20', NULL),
(2, 2, 15, '2023-04-03 13:48:35', NULL),
(3, 3, 5, '2023-12-21 19:46:22', NULL),
(4, 4, 4, '2023-12-21 21:04:19', NULL),
(5, 5, 3, '2023-12-21 21:53:46', NULL),
(6, 7, 3, '2023-12-22 17:48:44', NULL),
(7, 6, 4, '2023-12-22 17:48:51', NULL),
(8, 8, 5, '2023-12-22 17:52:36', NULL),
(9, 9, 16, '2023-12-22 17:58:21', NULL),
(10, 10, 2, '2023-12-22 18:03:46', NULL),
(11, 11, 6, '2023-12-22 18:17:59', NULL),
(12, 12, 4, '2023-12-22 18:22:45', NULL),
(13, 13, 6, '2023-12-22 18:28:03', NULL),
(14, 14, 15, '2023-12-22 18:35:51', NULL),
(15, 15, 15, '2023-12-22 18:40:35', NULL),
(16, 16, 15, '2023-12-22 18:45:08', NULL),
(17, 17, 16, '2023-12-22 18:49:12', NULL),
(18, 18, 15, '2023-12-22 18:53:33', NULL),
(20, 19, 2, '2023-12-22 21:05:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(30) NOT NULL,
  `client_id` int(30) NOT NULL,
  `delivery_address` text NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `order_type` tinyint(1) NOT NULL COMMENT '1= pickup,2= deliver',
  `amount` double NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT 0,
  `paid` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `client_id`, `delivery_address`, `payment_method`, `order_type`, `amount`, `status`, `paid`, `date_created`, `date_updated`) VALUES
(3, 1, 'Sample Address Only', 'cod', 1, 99999, 3, 1, '2023-04-03 13:09:19', '2023-04-03 13:14:47'),
(4, 2, 'Bunawan', 'cod', 1, 99999, 3, 1, '2023-12-22 17:00:05', '2023-12-22 17:01:10'),
(5, 2, 'Bunawan', 'cod', 2, 111111, 0, 0, '2023-12-22 17:00:17', NULL),
(6, 4, 'Prk.1-A Rizal Canocotan Tagum City', 'cod', 1, 40100, 3, 1, '2023-12-22 20:21:43', '2023-12-22 21:07:26');

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `order_id`, `product_id`, `quantity`, `price`, `total`) VALUES
(1, 3, 1, 1, 99999, 99999),
(2, 4, 1, 1, 99999, 99999),
(3, 5, 5, 1, 111111, 111111),
(4, 6, 9, 1, 1100, 1100),
(5, 6, 6, 1, 39000, 39000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(30) NOT NULL,
  `brand_id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `sub_category_id` int(30) NOT NULL,
  `name` varchar(250) NOT NULL,
  `price` float(12,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `brand_id`, `category_id`, `sub_category_id`, `name`, `price`, `status`, `date_created`) VALUES
(1, 2, 6, 4, 'Acer Predator Helios 300 PH315-52 (PH315-52-581R)', 99999.00, 1, '2023-04-03 10:48:32'),
(2, 2, 1, 2, 'Acer Aspire 3 A315-24P (A315-24P-R5XG)', 31349.00, 1, '2023-04-03 13:46:54'),
(3, 3, 6, 4, 'ACER NITRO 5', 80000.00, 1, '2023-12-21 19:45:18'),
(4, 1, 6, 4, 'ASUS STRIX G17', 60599.00, 1, '2023-12-21 21:02:49'),
(5, 1, 6, 5, 'ExpertBook B9 OLED', 111111.00, 1, '2023-12-21 21:52:28'),
(6, 12, 5, 12, 'Core I9 13TH GEN', 39000.00, 1, '2023-12-22 17:42:07'),
(7, 1, 5, 10, 'Asus ROG Strix GeForce RTX 4090 OC Edition 24GB GDDR6X Graphics Card', 129995.00, 1, '2023-12-22 17:47:14'),
(8, 9, 7, 6, 'ESET ANTI VIRUS', 5699.00, 1, '2023-12-22 17:52:20'),
(9, 8, 5, 17, 'Inplay Meteor 03 Black ATX Tempered Glass Case', 1100.00, 1, '2023-12-22 17:58:09'),
(10, 14, 5, 18, 'SteelSeries USB Apex 5 Hybrid Mechanical Gaming Keyboard – Per-Key RGB Illumination', 4500.00, 1, '2023-12-22 18:03:23'),
(11, 4, 6, 5, 'XPS 13 Plus Laptop', 58999.00, 1, '2023-12-22 18:17:47'),
(12, 4, 5, 14, 'Dell 27 4K UHD Monitor - S2721QS', 18247.00, 1, '2023-12-22 18:22:34'),
(13, 1, 5, 11, 'ASUS ROG Strix B650E-F Gaming WiFi AM5', 14363.00, 1, '2023-12-22 18:27:55'),
(14, 3, 5, 15, 'ALIENWARE TRI-MODE WIRELESS GAMING MOUSE - AW720M', 5679.00, 1, '2023-12-22 18:35:27'),
(15, 8, 5, 16, 'Inplay True Rated 450W/550W/650W/750W', 779.00, 1, '2023-12-22 18:40:20'),
(16, 15, 5, 8, 'Ramsta Memory DDR3 DDR4 ', 2100.00, 1, '2023-12-22 18:44:57'),
(17, 4, 5, 13, 'Ramsta 2.5', 2999.00, 1, '2023-12-22 18:49:02'),
(19, 1, 6, 4, 'Asus TUF FX504GE Gaming Laptop', 39995.00, 1, '2023-12-22 20:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `total_amount` double NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `order_id`, `total_amount`, `date_created`) VALUES
(1, 3, 99999, '2023-04-03 13:09:19'),
(2, 4, 99999, '2023-12-22 17:00:05'),
(3, 5, 111111, '2023-12-22 17:00:17'),
(4, 6, 40100, '2023-12-22 20:21:43');

-- --------------------------------------------------------

--
-- Table structure for table `specification_list`
--

CREATE TABLE `specification_list` (
  `id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specification_list`
--

INSERT INTO `specification_list` (`id`, `product_id`, `meta_field`, `meta_value`) VALUES
(53, 2, 'processor', 'AMD Athlon™ Gold 7220U dual-core processor'),
(54, 2, 'clock_speed', '2.4 GHz (MAX 3.7 GHz)'),
(55, 2, 'GPU', 'AMD Radeon Graphics'),
(56, 2, 'RAM', '8GB of onboard LPDDR5'),
(57, 2, 'RAM_slot', '(No Extra Slot)'),
(58, 2, 'SSD_OR_HDD', '256GB PCIe NVMe SSD'),
(59, 2, 'OS', '	Windows 11 Home'),
(60, 2, 'display_size', '39.6 cm (15.6\") LED 1920 x 1080'),
(61, 2, 'display_type', 'Acer ComfyView'),
(62, 2, 'display_touch', 'N/A'),
(63, 2, 'power_adapter', 'N/A'),
(64, 2, 'battery_capacity', '2-cell Li-ion battery 37 Wh 4810 mAh 7.7 V'),
(65, 2, 'battery_hour', 'Up to 6.50 Hour'),
(66, 2, 'dimension', '18.9 x 237.5 x 362.9 mm'),
(67, 2, 'weight', '1.8 kg'),
(68, 2, 'colors', 'Pure Silver'),
(69, 2, 'IO_ports', 'USB : Yes\r\nNumber of USB 2.0 Ports : 1\r\nNumber of USB 3.2 Gen 1 Port : 2\r\nNetwork (RJ-45) : Yes'),
(70, 2, 'fingerprint_sensor', 'N/A'),
(71, 2, 'camera', 'Yes'),
(72, 2, 'keyboard', 'Yes'),
(73, 2, 'touchpad', 'Yes'),
(74, 2, 'WIFI', 'IEEE 802.11ac/a/b/g/n'),
(75, 2, 'bluetooth', 'Bluetooth® 5.2'),
(76, 2, 'speaker', 'Yes'),
(77, 2, 'mic', 'Yes'),
(78, 2, 'other', 'N/A'),
(105, 3, 'processor', 'dtdTc'),
(106, 3, 'clock_speed', 'ct'),
(107, 3, 'GPU', 'ct'),
(108, 3, 'RAM', 'c'),
(109, 3, 'RAM_slot', 'tc'),
(110, 3, 'SSD_OR_HDD', 'tc'),
(111, 3, 'OS', 't'),
(112, 3, 'display_size', 'tc'),
(113, 3, 'display_type', 'tc'),
(114, 3, 'display_touch', 'tc'),
(115, 3, 'power_adapter', 'tyc'),
(116, 3, 'battery_capacity', 'c'),
(117, 3, 'battery_hour', 'tc'),
(118, 3, 'dimension', 'c'),
(119, 3, 'weight', 'c'),
(120, 3, 'colors', 'tr'),
(121, 3, 'IO_ports', 'tr'),
(122, 3, 'fingerprint_sensor', 't'),
(123, 3, 'camera', 'tc'),
(124, 3, 'keyboard', 'c'),
(125, 3, 'touchpad', 'gasrgs'),
(126, 3, 'WIFI', 'ct'),
(127, 3, 'bluetooth', 'ctc'),
(128, 3, 'speaker', 't'),
(129, 3, 'mic', 'dsavyt'),
(130, 3, 'other', 'tctfct'),
(157, 1, 'processor', 'Intel i5-9300H'),
(158, 1, 'clock_speed', '2.4GHz'),
(159, 1, 'GPU', 'NVIDIA GeForce RTX 2060 6GB GDDR6'),
(160, 1, 'RAM', '8GB DDR4 SDRAM'),
(161, 1, 'RAM_slot', '2'),
(162, 1, 'SSD_OR_HDD', 'SSD 512GB'),
(163, 1, 'OS', 'Windows 10 Home'),
(164, 1, 'display_size', '15.6\" Full HD 1920 x 1080, 144 Hz'),
(165, 1, 'display_type', 'ComfyView, In-plane Switching (IPS) Technology'),
(166, 1, 'display_touch', 'N/A'),
(167, 1, 'power_adapter', '180 W'),
(168, 1, 'battery_capacity', '4-cell Battery Lithium Polymer, 3815 mAh'),
(169, 1, 'battery_hour', '6 Hour'),
(170, 1, 'dimension', '23.15 x 361.4 x 254.2 mm'),
(171, 1, 'weight', '2.4Kg'),
(172, 1, 'colors', 'Black'),
(173, 1, 'IO_ports', '3x USB Ports\r\n1x Network (RJ-45)\r\n1x HDMI'),
(174, 1, 'fingerprint_sensor', 'N/A'),
(175, 1, 'camera', 'N/A'),
(176, 1, 'keyboard', 'Yes, Keyboard Backlight'),
(177, 1, 'touchpad', 'Yes'),
(178, 1, 'WIFI', 'IEEE 802.11 a/b/g/n/ac/ax Gigabit Ethernet'),
(179, 1, 'bluetooth', 'N/A'),
(180, 1, 'speaker', 'Stereo 2 Speakers'),
(181, 1, 'mic', 'Yes'),
(182, 1, 'other', 'Sample Other Information'),
(339, 4, 'processor', 'AMD Ryzen™ 7 4800H Mobile Processor (8-core/16-thread, 12MB Cache, 4.2 GHz max boost)'),
(340, 4, 'clock_speed', '4.2 GHz'),
(341, 4, 'GPU', 'GeForce RTX™ 3050 Laptop GPU'),
(342, 4, 'RAM', '16GB DDR4-3200 SO-DIMM x 2'),
(343, 4, 'RAM_slot', '2'),
(344, 4, 'SSD_OR_HDD', '1TB PCIe® 3.0 NVMe™ M.2 SSD\r\n'),
(345, 4, 'OS', 'Windows 11 Home'),
(346, 4, 'display_size', '17.3-inch'),
(347, 4, 'display_type', 'FHD (1920 x 1080) 16:9\r\nIPS-level\r\nAnti-glare display'),
(348, 4, 'display_touch', 'NO'),
(349, 4, 'power_adapter', 'ø6.0, 200W AC Adapter, Output: 20V DC, 10A, 200W, Input: 100-240V AC, 50/60Hz universal\r\nTYPE-C, 100W AC Adapter, Output: 20V DC, 5A, 100W, Input: 100~240V AC 50/60Hz universal'),
(350, 4, 'battery_capacity', '56Wrs'),
(351, 4, 'battery_hour', '10-15 hours'),
(352, 4, 'dimension', '39.5 x 28.2 x 2.14 ~ 2.46 cm (15.55\" x 11.10\" x 0.84\" ~ 0.97\")\r\n'),
(353, 4, 'weight', '2.40 Kg (5.29 lbs)'),
(354, 4, 'colors', 'BLACK / BLUE / WHITE'),
(355, 4, 'IO_ports', '1x 3.5mm Combo Audio Jack\r\n1x HDMI 2.0b\r\n3x USB 3.2 Gen 1 Type-A\r\n1x USB 3.2 Gen 2 Type-C support DisplayPort™ / power delivery / G-SYNC\r\n1x RJ45 LAN port'),
(356, 4, 'fingerprint_sensor', 'N/A'),
(357, 4, 'camera', 'FHD 1080P@60FPS external camera'),
(358, 4, 'keyboard', 'Backlit Chiclet Keyboard'),
(359, 4, 'touchpad', '4-Zone RGB\r\nTouchpad'),
(360, 4, 'WIFI', 'Wi-Fi 6(802.11ax) (Dual band) 2*2'),
(361, 4, 'bluetooth', 'Bluetooth® 5.2 Wireless Card '),
(362, 4, 'speaker', 'Dolby Atmos\r\nAI noise-canceling technology\r\n'),
(363, 4, 'mic', 'Built-in array microphone\r\n2-speaker system'),
(364, 4, 'other', 'n/a'),
(365, 5, 'processor', '\r\nIntel® Core™ i7-1355U Processor 1.7GHz (12M Cache, up to 5GHz,10 cores)'),
(366, 5, 'clock_speed', '1,7ghZ'),
(367, 5, 'GPU', 'Intel Iris Xᵉ Graphics (available for Intel® Core™ i5/i7/i9 with dual channel memory)'),
(368, 5, 'RAM', '16GB LPDDR5 on board, Memory Max Up to:16GB'),
(369, 5, 'RAM_slot', '2'),
(370, 5, 'SSD_OR_HDD', '1TB M.2 2280 NVMe™ PCIe® 4.0 Performance SSD'),
(371, 5, 'OS', 'Windows 11 Pro - ASUS recommends Windows 11 Pro for business'),
(372, 5, 'display_size', ' 14.0-inch'),
(373, 5, 'display_type', 'OLED'),
(374, 5, 'display_touch', 'NO'),
(375, 5, 'power_adapter', 'n/a'),
(376, 5, 'battery_capacity', '\r\n63WHrs'),
(377, 5, 'battery_hour', '3-cell Li-ion\r\nLong life rechargeable lithium polymer battery.\r\n'),
(378, 5, 'dimension', '\r\n31.10 x 21.50 x 1.57 ~ 1.57 cm (12.24\" x 8.46\" x 0.62\" ~ 0.62\")'),
(379, 5, 'weight', '0.99 kg (2.18 lbs)'),
(380, 5, 'colors', 'Star Black'),
(381, 5, 'IO_ports', '1x USB 3.2 Gen 2 Type-A\r\n2x Thunderbolt™ 4, compliant with USB4, supports display / power delivery\r\n1x micro HDMI (RJ45 lan)\r\n1x HDMI 2.1 TMDS\r\n1x USB 2.0 Type-A\r\n1x Micro SD Card Reader + SIM Card Slot\r\n'),
(382, 5, 'fingerprint_sensor', 'N/A'),
(383, 5, 'camera', '1080p FHD camera with IR function to support Windows Hello\r\nWith privacy shutter\r\n'),
(384, 5, 'keyboard', 'Backlit Chiclet Keyboard'),
(385, 5, 'touchpad', '1.5mm Key-travel, Spill-resistant Keyboard, Support NumberPad'),
(386, 5, 'WIFI', '\r\nWi-Fi 6E(802.11ax) (Dual band) 2*2 '),
(387, 5, 'bluetooth', 'Bluetooth® 5.3 Wireless Card'),
(388, 5, 'speaker', 'Dolby Atmos\r\nSmart Amp Technology\r\nBuilt-in speaker\r\n'),
(389, 5, 'mic', 'Built-in array microphone\r\nwith Cortana support'),
(390, 5, 'other', 'n/a'),
(417, 6, 'processor', 'Intel core i9 13th Gen'),
(418, 6, 'clock_speed', '5.60 GHz'),
(419, 6, 'GPU', 'N/A'),
(420, 6, 'RAM', 'N/A'),
(421, 6, 'RAM_slot', 'N/A'),
(422, 6, 'SSD_OR_HDD', 'N/A'),
(423, 6, 'OS', 'N/A'),
(424, 6, 'display_size', 'N/A'),
(425, 6, 'display_type', 'N/A'),
(426, 6, 'display_touch', 'N/A'),
(427, 6, 'power_adapter', 'N/A'),
(428, 6, 'battery_capacity', 'N/A'),
(429, 6, 'battery_hour', 'N/A'),
(430, 6, 'dimension', 'N/A'),
(431, 6, 'weight', 'N/A'),
(432, 6, 'colors', 'N/A'),
(433, 6, 'IO_ports', 'N/A'),
(434, 6, 'fingerprint_sensor', 'N/A'),
(435, 6, 'camera', 'N/A'),
(436, 6, 'keyboard', 'N.A'),
(437, 6, 'touchpad', 'N/A'),
(438, 6, 'WIFI', 'NA'),
(439, 6, 'bluetooth', 'NA'),
(440, 6, 'speaker', 'NA'),
(441, 6, 'mic', 'NA'),
(442, 6, 'other', 'NA'),
(495, 7, 'processor', 'NA'),
(496, 7, 'clock_speed', 'NA'),
(497, 7, 'GPU', 'NA'),
(498, 7, 'RAM', 'NA'),
(499, 7, 'RAM_slot', 'NA'),
(500, 7, 'SSD_OR_HDD', 'NA'),
(501, 7, 'OS', 'NA'),
(502, 7, 'display_size', 'NA'),
(503, 7, 'display_type', 'NA'),
(504, 7, 'display_touch', 'NA'),
(505, 7, 'power_adapter', 'NA'),
(506, 7, 'battery_capacity', 'NA'),
(507, 7, 'battery_hour', 'NA'),
(508, 7, 'dimension', 'NA'),
(509, 7, 'weight', 'NA'),
(510, 7, 'colors', 'NA'),
(511, 7, 'IO_ports', 'NA'),
(512, 7, 'fingerprint_sensor', 'NA'),
(513, 7, 'camera', 'NA'),
(514, 7, 'keyboard', 'NA'),
(515, 7, 'touchpad', 'NA'),
(516, 7, 'WIFI', 'NA'),
(517, 7, 'bluetooth', 'NA'),
(518, 7, 'speaker', 'NA'),
(519, 7, 'mic', 'NA'),
(520, 7, 'other', 'The ROG Strix GeForce RTX® 4090 brings a whole new meaning to going with the flow. Inside and out, every element of the card gives the monstrous GPU headroom to breathe freely and achieve ultimate performance. The unleashed reign of the NVIDIA Ada Lovelace architecture is here.\r\n\r\nROG Strix GeForce RTX® 4090 OC Edition 24GB GDDR6X with DLSS 3 and chart-topping thermal performance\r\n\r\nNVIDIA Ada Lovelace Streaming Multiprocessors: Up to 2x performance and power efficiency\r\n4th Generation Tensor Cores: Up to 4x performance with DLSS 3 vs. brute-force rendering \r\n3rd Generation RT Cores: Up to 2X ray tracing performance\r\nOC mode: Boost clock 2640 MHz (OC mode)/ 2610 MHz (Gaming mode) \r\nAxial-tech fans scaled up for 23% more airflow\r\nNew patented vapor chamber with milled heatspreader for lower GPU temps \r\n3.5-slot design: massive fin array optimized for airflow from the three Axial-tech fans \r\nDiecast shroud, frame, and backplate add rigidity and are vented to further maximize airflow and heat dissipation\r\nDigital power control with high-current power stages and 15K capacitors to fuel maximum performance\r\nAuto-Extreme precision automated manufacturing for higher reliability \r\nGPU Tweak III software provides intuitive performance tweaking, thermal controls, and system monitoring'),
(521, 8, 'processor', 'NA'),
(522, 8, 'clock_speed', 'NA'),
(523, 8, 'GPU', 'NA'),
(524, 8, 'RAM', 'NA'),
(525, 8, 'RAM_slot', 'NA'),
(526, 8, 'SSD_OR_HDD', 'NA'),
(527, 8, 'OS', 'NA'),
(528, 8, 'display_size', 'NA'),
(529, 8, 'display_type', 'NA'),
(530, 8, 'display_touch', 'NA'),
(531, 8, 'power_adapter', 'NA'),
(532, 8, 'battery_capacity', 'NA'),
(533, 8, 'battery_hour', 'NA'),
(534, 8, 'dimension', 'NA'),
(535, 8, 'weight', 'NA'),
(536, 8, 'colors', 'NA'),
(537, 8, 'IO_ports', 'NA'),
(538, 8, 'fingerprint_sensor', 'NA'),
(539, 8, 'camera', 'NA'),
(540, 8, 'keyboard', 'AN'),
(541, 8, 'touchpad', 'NA'),
(542, 8, 'WIFI', 'NA'),
(543, 8, 'bluetooth', 'NA'),
(544, 8, 'speaker', 'NAN'),
(545, 8, 'mic', 'NA'),
(546, 8, 'other', 'Top Protection from Virus & Malware. Buy Latest Version of ESET Today! Anti Malware. Antivirus. Anti-Theft. Vulnerability Shield. Personal Firewall. Antispyware'),
(547, 9, 'processor', 'NA'),
(548, 9, 'clock_speed', 'NA'),
(549, 9, 'GPU', 'NAN'),
(550, 9, 'RAM', 'AN'),
(551, 9, 'RAM_slot', 'NA'),
(552, 9, 'SSD_OR_HDD', 'NA'),
(553, 9, 'OS', 'NA'),
(554, 9, 'display_size', 'NA'),
(555, 9, 'display_type', 'NA'),
(556, 9, 'display_touch', 'NA'),
(557, 9, 'power_adapter', 'NA'),
(558, 9, 'battery_capacity', 'NAN'),
(559, 9, 'battery_hour', 'AA'),
(560, 9, 'dimension', 'Front: 12cm*3\r\nTop: 12cm*2\r\nBack: 12cm*1\r\nExpansion Slot: 7\r\nHDD/SSD Slot: HDD*2/SSD*3\r\nMax VGA Card Length: 305mm\r\nMax CPU Cooler Height: 165mm'),
(561, 9, 'weight', '1KG'),
(562, 9, 'colors', 'BLACK / WHITE '),
(563, 9, 'IO_ports', ' USB 2.0*2/HD Audio'),
(564, 9, 'fingerprint_sensor', 'NA'),
(565, 9, 'camera', 'NA'),
(566, 9, 'keyboard', 'NA'),
(567, 9, 'touchpad', 'NA'),
(568, 9, 'WIFI', 'NA'),
(569, 9, 'bluetooth', 'NA'),
(570, 9, 'speaker', 'NA'),
(571, 9, 'mic', 'NA'),
(572, 9, 'other', 'FANCY CHEAP SYSTEM UNIT'),
(599, 10, 'processor', 'NA'),
(600, 10, 'clock_speed', 'NA'),
(601, 10, 'GPU', 'NANA'),
(602, 10, 'RAM', 'NA'),
(603, 10, 'RAM_slot', 'NAN'),
(604, 10, 'SSD_OR_HDD', 'NA'),
(605, 10, 'OS', 'NA'),
(606, 10, 'display_size', 'NA'),
(607, 10, 'display_type', 'NA'),
(608, 10, 'display_touch', 'NA'),
(609, 10, 'power_adapter', 'NA'),
(610, 10, 'battery_capacity', 'NA'),
(611, 10, 'battery_hour', 'NA'),
(612, 10, 'dimension', '900 x 300 x 4 millimeter; 35.43 inches x 11.81 inches'),
(613, 10, 'weight', 'NA'),
(614, 10, 'colors', 'Hybrid Blue – Tactile & Clicky'),
(615, 10, 'IO_ports', 'USB'),
(616, 10, 'fingerprint_sensor', 'NA'),
(617, 10, 'camera', 'NA'),
(618, 10, 'keyboard', 'NA'),
(619, 10, 'touchpad', 'NA'),
(620, 10, 'WIFI', 'NA'),
(621, 10, 'bluetooth', 'NA'),
(622, 10, 'speaker', 'NA'),
(623, 10, 'mic', 'NA'),
(624, 10, 'other', 'NA'),
(625, 11, 'processor', '12th Generation Intel® Core™ i7-1260P (18MB Cache, up to 4.7 GHz, 12 cores)\r\n12th Generation Intel® Core™ i5-1240P (12MB Cache, up to 4.4 GHz, 12 cores)'),
(626, 11, 'clock_speed', '4.4ghz'),
(627, 11, 'GPU', 'Integrated:\r\nIntel® Iris Xe Graphics'),
(628, 11, 'RAM', '16GB, LPDDR5, 5200 MHz, integrated, dual channel'),
(629, 11, 'RAM_slot', '2'),
(630, 11, 'SSD_OR_HDD', '512G M.2 PCIe Gen 4 NVMe Solid State Drive\r\n1TB M.2 PCIe Gen 4 NVMe Solid State Drive'),
(631, 11, 'OS', 'Windows 11 Pro, 64-bit\r\nWindows 11 Home, 64-bit'),
(632, 11, 'display_size', '13.4\", 3.5K 3456x2160, 60Hz, OLED, Touch, Anti-Reflect, 400 nit, InfinityEdge'),
(633, 11, 'display_type', 'OLED'),
(634, 11, 'display_touch', 'yes'),
(635, 11, 'power_adapter', 'Na'),
(636, 11, 'battery_capacity', '3-cell, 55 Wh \"smart\" lithium-ion, integrated'),
(637, 11, 'battery_hour', '55wh'),
(638, 11, 'dimension', 'Height : 15.28mm (0.60 in.)\r\nWidth: 295.30 mm (11.63 in.)\r\nDepth: 199.04 mm (7.84 in.)\r\n'),
(639, 11, 'weight', 'Starting weight: 1.23 kg (2.71 lbs.), 1.26 kg (2.77 lbs.) with OLED'),
(640, 11, 'colors', 'Platinum Silver\r\nGraphite'),
(641, 11, 'IO_ports', '2 x Thunderbolt™ 4 (USB Type-C™ with DisplayPort and Power Delivery)\r\nUSB-C to USB-A 3.0 adapter (included in the box)\r\nUSB-C to 3.5mm headset adapter (included in the box)'),
(642, 11, 'fingerprint_sensor', 'YES'),
(643, 11, 'camera', '720p at 30 fps HD RGB camera, 400p at 30 fps IR camera,'),
(644, 11, 'keyboard', 'Light Gray Backlit Keyboard (US/International) with Fingerprint Reader\r\nMagnetite Backlit Keyboard (US/International) with Fingerprint Reader'),
(645, 11, 'touchpad', 'Magnetite Backlit Keyboard (US/International) with Fingerprint Reader'),
(646, 11, 'WIFI', 'Intel® Killer™ Wi-Fi 6 1675 (AX211) 2x2 '),
(647, 11, 'bluetooth', 'Bluetooth 5.2 Wireless Card\r\n\r\n'),
(648, 11, 'speaker', 'Quad-speaker design with 8W total output\r\nStudio quality tuning with Waves MaxxAudio®Pro and Waves Nx®3D audio'),
(649, 11, 'mic', 'dual-array microphones'),
(650, 11, 'other', 'Bring ideas to life at a blistering pace with our most powerful 13″ laptop—featuring 12th Gen Intel® Core™ processors and innovative, modern design.'),
(651, 12, 'processor', 'NA'),
(652, 12, 'clock_speed', 'NA'),
(653, 12, 'GPU', 'NA'),
(654, 12, 'RAM', 'AN'),
(655, 12, 'RAM_slot', 'NA'),
(656, 12, 'SSD_OR_HDD', 'NA'),
(657, 12, 'OS', 'NA'),
(658, 12, 'display_size', '27\"\r\n4K UHD (2160p) 3840 x 2160 at 60 Hz'),
(659, 12, 'display_type', 'UHD'),
(660, 12, 'display_touch', 'NO'),
(661, 12, 'power_adapter', 'NA'),
(662, 12, 'battery_capacity', 'NA'),
(663, 12, 'battery_hour', 'NA'),
(664, 12, 'dimension', 'NA'),
(665, 12, 'weight', 'NA'),
(666, 12, 'colors', 'NA'),
(667, 12, 'IO_ports', 'HDMI, DisplayPort 1.2, Audio line-out'),
(668, 12, 'fingerprint_sensor', 'NA'),
(669, 12, 'camera', 'NAN'),
(670, 12, 'keyboard', 'ANA'),
(671, 12, 'touchpad', 'NANA'),
(672, 12, 'WIFI', 'NA'),
(673, 12, 'bluetooth', 'NA'),
(674, 12, 'speaker', 'Speakers - stereo'),
(675, 12, 'mic', 'NA'),
(676, 12, 'other', 'NA'),
(703, 13, 'processor', 'NNA'),
(704, 13, 'clock_speed', 'NA'),
(705, 13, 'GPU', 'NA'),
(706, 13, 'RAM', 'DDR5'),
(707, 13, 'RAM_slot', 'NA'),
(708, 13, 'SSD_OR_HDD', 'NA'),
(709, 13, 'OS', 'NA'),
(710, 13, 'display_size', 'NA'),
(711, 13, 'display_type', 'NA'),
(712, 13, 'display_touch', 'NA'),
(713, 13, 'power_adapter', 'NA'),
(714, 13, 'battery_capacity', 'NA'),
(715, 13, 'battery_hour', 'NA'),
(716, 13, 'dimension', 'NA'),
(717, 13, 'weight', 'NA'),
(718, 13, 'colors', 'NA'),
(719, 13, 'IO_ports', 'NA'),
(720, 13, 'fingerprint_sensor', 'NA'),
(721, 13, 'camera', 'AA'),
(722, 13, 'keyboard', 'NNA'),
(723, 13, 'touchpad', 'NA'),
(724, 13, 'WIFI', 'NA'),
(725, 13, 'bluetooth', 'NA'),
(726, 13, 'speaker', 'NA'),
(727, 13, 'mic', 'NA'),
(728, 13, 'other', 'NA'),
(729, 14, 'processor', 'Na'),
(730, 14, 'clock_speed', 'na'),
(731, 14, 'GPU', 'na'),
(732, 14, 'RAM', 'na'),
(733, 14, 'RAM_slot', 'na'),
(734, 14, 'SSD_OR_HDD', 'na'),
(735, 14, 'OS', 'na'),
(736, 14, 'display_size', 'na'),
(737, 14, 'display_type', 'na'),
(738, 14, 'display_touch', 'na'),
(739, 14, 'power_adapter', 'na'),
(740, 14, 'battery_capacity', 'na'),
(741, 14, 'battery_hour', 'na'),
(742, 14, 'dimension', 'na'),
(743, 14, 'weight', 'na'),
(744, 14, 'colors', 'an'),
(745, 14, 'IO_ports', 'na'),
(746, 14, 'fingerprint_sensor', 'nan'),
(747, 14, 'camera', 'aa'),
(748, 14, 'keyboard', 'na'),
(749, 14, 'touchpad', 'na'),
(750, 14, 'WIFI', 'na'),
(751, 14, 'bluetooth', 'na'),
(752, 14, 'speaker', 'na'),
(753, 14, 'mic', 'na'),
(754, 14, 'other', 'na'),
(781, 15, 'processor', 'na'),
(782, 15, 'clock_speed', 'na'),
(783, 15, 'GPU', 'na'),
(784, 15, 'RAM', 'na'),
(785, 15, 'RAM_slot', 'na'),
(786, 15, 'SSD_OR_HDD', 'na'),
(787, 15, 'OS', 'na'),
(788, 15, 'display_size', 'an'),
(789, 15, 'display_type', 'na'),
(790, 15, 'display_touch', 'na'),
(791, 15, 'power_adapter', 'na'),
(792, 15, 'battery_capacity', 'nana'),
(793, 15, 'battery_hour', 'nn'),
(794, 15, 'dimension', 'nan'),
(795, 15, 'weight', 'ann'),
(796, 15, 'colors', 'nnn'),
(797, 15, 'IO_ports', 'nana'),
(798, 15, 'fingerprint_sensor', 'nana'),
(799, 15, 'camera', 'nan'),
(800, 15, 'keyboard', 'na'),
(801, 15, 'touchpad', 'na'),
(802, 15, 'WIFI', 'na'),
(803, 15, 'bluetooth', 'na'),
(804, 15, 'speaker', 'na'),
(805, 15, 'mic', 'na'),
(806, 15, 'other', 'na'),
(859, 16, 'processor', 'na'),
(860, 16, 'clock_speed', ' 1600Mhz 2666Mhz 3200Mhz'),
(861, 16, 'GPU', 'na'),
(862, 16, 'RAM', '4Gb 8Gb 16Gb'),
(863, 16, 'RAM_slot', 'na'),
(864, 16, 'SSD_OR_HDD', 'na'),
(865, 16, 'OS', 'na'),
(866, 16, 'display_size', 'na'),
(867, 16, 'display_type', 'na'),
(868, 16, 'display_touch', 'na'),
(869, 16, 'power_adapter', 'na'),
(870, 16, 'battery_capacity', 'na'),
(871, 16, 'battery_hour', 'na'),
(872, 16, 'dimension', 'na'),
(873, 16, 'weight', 'na'),
(874, 16, 'colors', 'na'),
(875, 16, 'IO_ports', 'na'),
(876, 16, 'fingerprint_sensor', 'na'),
(877, 16, 'camera', 'na'),
(878, 16, 'keyboard', 'na'),
(879, 16, 'touchpad', 'na'),
(880, 16, 'WIFI', 'na'),
(881, 16, 'bluetooth', 'na'),
(882, 16, 'speaker', 'na'),
(883, 16, 'mic', 'na'),
(884, 16, 'other', 'na'),
(911, 17, 'processor', 'NA'),
(912, 17, 'clock_speed', 'nA'),
(913, 17, 'GPU', 'NA'),
(914, 17, 'RAM', 'NA'),
(915, 17, 'RAM_slot', 'NA'),
(916, 17, 'SSD_OR_HDD', ' 128gb 256gb 512gb 1tb'),
(917, 17, 'OS', 'NA'),
(918, 17, 'display_size', 'NA'),
(919, 17, 'display_type', 'NA'),
(920, 17, 'display_touch', 'NA'),
(921, 17, 'power_adapter', 'NA'),
(922, 17, 'battery_capacity', 'NA'),
(923, 17, 'battery_hour', 'NA'),
(924, 17, 'dimension', 'NA'),
(925, 17, 'weight', 'NA'),
(926, 17, 'colors', 'NA'),
(927, 17, 'IO_ports', 'NA'),
(928, 17, 'fingerprint_sensor', 'NA'),
(929, 17, 'camera', 'NA'),
(930, 17, 'keyboard', 'NA'),
(931, 17, 'touchpad', 'NA'),
(932, 17, 'WIFI', 'NA'),
(933, 17, 'bluetooth', 'AN'),
(934, 17, 'speaker', 'NA'),
(935, 17, 'mic', 'NA'),
(936, 17, 'other', 'CHEAP AFFORDABLE RAM :)'),
(1041, 19, 'processor', 'Intel Kaby Lake Core i7-8750H CPU'),
(1042, 19, 'clock_speed', 'n/a'),
(1043, 19, 'GPU', 'Intel HD 630 + Nvidia GT 1050 Ti 4GB'),
(1044, 19, 'RAM', '16GB DDr4 (2x DIMMs)'),
(1045, 19, 'RAM_slot', 'n/a'),
(1046, 19, 'SSD_OR_HDD', '256 GB SSD (M.2 PCle) + 1 TB 5400 rpm HDD (2.5\")'),
(1047, 19, 'OS', 'Windows 10'),
(1048, 19, 'display_size', '15.6 inch, 1920 x 1080 px, 120 Hz, TN, non-touch, matte'),
(1049, 19, 'display_type', 'n/a'),
(1050, 19, 'display_touch', 'none'),
(1051, 19, 'power_adapter', '48 Wh, 120 W charger '),
(1052, 19, 'battery_capacity', 'n/a'),
(1053, 19, 'battery_hour', 'n/a'),
(1054, 19, 'dimension', '384mm or 15.11\" (w) x 262 mm or 10.31\" (d) x 25 mm or 0.99\"(h)'),
(1055, 19, 'weight', '5.02 lbs (2.28 kg) + 1.1 lbs (.5 kg) for the charger'),
(1056, 19, 'colors', 'black'),
(1057, 19, 'IO_ports', '1 x USB 2.0, 2 x USB 3.0, HDMI, LAN, SD card reader, mic/headphone, Kensington Lock'),
(1058, 19, 'fingerprint_sensor', 'none'),
(1059, 19, 'camera', 'yes'),
(1060, 19, 'keyboard', 'red backlit keyboard'),
(1061, 19, 'touchpad', 'n/a'),
(1062, 19, 'WIFI', 'Gigabit LAN, Wireless AC (Intel AC 9560)'),
(1063, 19, 'bluetooth', 'Bluetooth 5.0'),
(1064, 19, 'speaker', 'n/a'),
(1065, 19, 'mic', 'n/a'),
(1066, 19, 'other', 'n/a');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(30) NOT NULL,
  `parent_id` int(30) NOT NULL,
  `sub_category` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `parent_id`, `sub_category`, `description`, `status`, `date_created`) VALUES
(1, 1, 'Desktop', 'Pellentesque congue dui at leo ullamcorper rutrum. Sed semper hendrerit lectus, at varius diam pretium id. Proin vel metus in orci pulvinar condimentum.', 1, '2023-04-03 09:36:53'),
(2, 1, 'Laptop', 'Donec nibh lorem, convallis eu libero sit amet, porttitor molestie neque.', 1, '2023-04-03 09:37:12'),
(3, 1, 'Tablets', 'Integer ante velit, porta ac magna vitae, maximus semper dui. Integer vitae nisi et erat tincidunt luctus. Proin condimentum aliquet quam vel interdum.', 1, '2023-04-03 09:37:42'),
(4, 6, 'Gaming', 'fiuaesgfuea uiafeafa', 1, '2023-12-21 19:40:15'),
(5, 6, 'Office', 'afjubsaufahfa', 1, '2023-12-21 19:40:30'),
(6, 7, 'Anti Virus', 'iugfasuyfgeasfha ', 1, '2023-12-21 19:41:04'),
(7, 7, 'Opearting System', 'hfuaisehfuiya eagfyasfbasea', 1, '2023-12-21 19:41:19'),
(8, 5, 'RAM', 'geaufeafj evasyfvejafa', 1, '2023-12-21 19:41:52'),
(9, 7, 'Application Software', 'Application software is a type of computer program that performs a specific personal, educational, and business function. ', 1, '2023-12-22 16:15:06'),
(10, 5, 'Graphics Processing Unit (GPU)', ' A dedicated graphics card is a wholly separate processor from the CPU and has its own dedicated memory.', 1, '2023-12-22 16:17:16'),
(11, 5, 'Motherboard', 'Application software is a type of computer program that performs a specific personal, educational, and business function. ', 1, '2023-12-22 16:22:05'),
(12, 5, 'Central Processing Unit (CPU)', 'The Central Processing Unit (CPU) is the primary component of a computer that acts as its &ldquo;control center.&rdquo; The CPU, also referred to as the &ldquo;central&rdquo; or &ldquo;main&rdquo; processor, is a complex set of electronic circuitry that runs the machine&#039;s operating system and apps.', 1, '2023-12-22 16:23:24'),
(13, 5, 'SSD', 'A solid-state drive (SSD) is a semiconductor-based storage device, which typically uses NAND flash memory to save persistent data. Each NAND flash memory chip consists of an array of blocks, also known as a grid, and within each block, there is an array of memory cells, known as pages or sectors.', 1, '2023-12-22 16:24:14'),
(14, 5, 'Monitor', 'A computer monitor is an output device that displays information in pictorial or textual form. A discrete monitor comprises a visual display, support electronics, power supply, housing, electrical connectors, and external user controls.', 1, '2023-12-22 16:24:45'),
(15, 5, 'Mouse', 'The mouse is a small, movable device that lets you control a range of things on a computer. Most types of mouse have two buttons, and some will have a wheel in between the buttons.', 1, '2023-12-22 16:25:52'),
(16, 5, 'Power Supply Unit (PSU)', 'A power supply unit (PSU) converts mains AC to low-voltage regulated DC power for the internal components of a computer.', 1, '2023-12-22 16:26:46'),
(17, 5, 'Case', 'The computer case is the metal and plastic box that contains the main components of the computer, including the motherboard, central processing unit (CPU), and power supply.', 1, '2023-12-22 16:27:46'),
(18, 5, 'Keyboard', 'Description. A computer keyboard is an input device used to enter characters and functions into the computer system by pressing buttons, or keys. It is the primary device used to enter text.', 1, '2023-12-22 16:28:16');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'BYTE Basket E-commerce Management System'),
(6, 'short_name', 'BYTE Basket'),
(11, 'logo', 'uploads/1703250900_BYTE_2.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/1703250900_1703092980_BYTE_Basket_2.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'ADMINISTRATOR', ' ', 'admin', '$2y$10$l5r4wABt0nzF90MF5PXl2Oq/jP3cH2Mkkdh.LIBI2PFmAzj4iM/hG', 'uploads/1703157840_1703078340_admin-logo.png', NULL, 1, '2021-01-20 14:02:37', '2023-12-23 16:36:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specification_list`
--
ALTER TABLE `specification_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id_fk` (`product_id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `specification_list`
--
ALTER TABLE `specification_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1067;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `specification_list`
--
ALTER TABLE `specification_list`
  ADD CONSTRAINT `product_id_fk` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
